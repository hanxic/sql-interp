# Changelog for project-cis5520

## 23fa
- Uses lts-21.6
- GHC2021 language pragma for real

## 22fa
- Uses lts-19.19
- GHC2021 language + common stanza
